#include <stdio.h>
#include <stdlib.h>
#include "SDL/include/SDL.h"
#include "SDL/include/SDL_image.h"

#pragma comment( lib, "SDL/lib/x86/SDL2.lib")
#pragma comment( lib, "SDL/lib/x86/SDL2main.lib")
#pragma comment( lib, "SDL/lib/x86/SDL2_image.lib")

int main(int argc, char* args[])
{
	int i = 0;
	int j = 0;
	int q = 0;
	bool shot = false;
	bool quit = false;
	int x = 288;
	int y = 208;

	IMG_INIT_JPG;

	SDL_Texture* texture;
	SDL_Event event;
	SDL_Surface* surface1;
	SDL_Surface* surface2;
	SDL_Surface* surface3;
	SDL_Init(SDL_INIT_EVERYTHING);
	SDL_Window *window;
	SDL_Renderer *renderer;
	SDL_Surface *image = IMG_Load("spaceshipsprites.png");
	
	SDL_Rect spaceship;
	spaceship.x = 35;
	spaceship.y = 0;
	spaceship.h = 37;
	spaceship.w = 47;

	SDL_Rect laser;
	laser.x = 2;
	laser.y = 130;
	laser.h = 11;
	laser.w = 7;

	SDL_Rect L_spaceship;
	L_spaceship.x = 0;
	L_spaceship.y = 0;
	L_spaceship.h = 38;
	L_spaceship.w = 36;
	
	SDL_CreateWindowAndRenderer(640, 480, SDL_WINDOW_RESIZABLE, &window, &renderer);

    surface1 = SDL_LoadBMP("Spaceship.bmp");
    texture = SDL_CreateTextureFromSurface(renderer, image); 
	surface1->clip_rect.h = 57;
	surface1->clip_rect.w = 67;
	surface1->clip_rect.x = x;
	surface1->clip_rect.y = y;

	surface2 = SDL_LoadBMP("Spaceship1.bmp");
	texture = SDL_CreateTextureFromSurface(renderer, image);
	surface2->clip_rect.h = 57;
	surface2->clip_rect.w = 67;
	surface2->clip_rect.x = x;
	surface2->clip_rect.y = y;

	surface3 = SDL_LoadBMP("Spaceship2.bmp");
	texture = SDL_CreateTextureFromSurface(renderer, image);
	surface3->clip_rect.h = 57;
	surface3->clip_rect.w = 67;
	surface3->clip_rect.x = x;
	surface3->clip_rect.y = y;
	
	SDL_Texture* texture2;
	SDL_Surface* shoot;
	
		shoot = SDL_LoadBMP("laser.bmp");
		texture2 = SDL_CreateTextureFromSurface(renderer, image);
		shoot->clip_rect.h = 20;
		shoot->clip_rect.w = 10;
		shoot->clip_rect.x = 1000;
		shoot->clip_rect.y = 1000;
	

	while (quit == false)
	{
		
			if (i % 5 == 0)
			{
					shoot->clip_rect.y--;
			}
			if (SDL_PollEvent(&event))
			{

				switch (event.type)
				{
				case SDL_KEYDOWN:
				{

					switch (event.key.keysym.sym)
					{

					case SDLK_ESCAPE:
					{
						quit = true;
						break;
					}
					case SDLK_LEFT:
					{
						surface1->clip_rect.x -= 10;
						surface2->clip_rect.x -= 10;
						break;
					}
					case SDLK_RIGHT:
					{
						surface1->clip_rect.x += 10;
						break;
					}
					case SDLK_UP:
					{
						surface1->clip_rect.y -= 10;
						break;
					}
					case SDLK_DOWN:
					{
						surface1->clip_rect.y += 10;
						break;
					}
					case SDLK_SPACE:
					{
						
						shoot->clip_rect.x = surface1->clip_rect.x+29;
						shoot->clip_rect.y = surface1->clip_rect.y;
						break;
						
					}
					default:
						break;
					}

				}
				}

			}

			SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);

			SDL_RenderClear(renderer);

			SDL_RenderCopy(renderer, texture2, &laser, &shoot->clip_rect);

			SDL_RenderCopy(renderer, texture, &L_spaceship, &surface2->clip_rect);

			SDL_RenderCopy(renderer, texture, &spaceship, &surface1->clip_rect);

			SDL_RenderPresent(renderer);
			i++;

	}

	SDL_Quit();
	return(EXIT_SUCCESS);
}