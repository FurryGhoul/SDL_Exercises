#include <stdio.h>
#include <stdlib.h>
#include "SDL/include/SDL.h"

#pragma comment( lib, "SDL/lib/x86/SDL2.lib")
#pragma comment( lib, "SDL/lib/x86/SDL2main.lib")

int main(int argc, char* args[])
{
	int i = 0;
	int j = 1;
	bool shot = false;
	bool quit = false;
	int x = 288;
	int y = 208;
	SDL_Texture* texture;
	SDL_Event event;
	SDL_Surface* surface;
	SDL_Init(SDL_INIT_EVERYTHING);
	SDL_Window *window;
	SDL_Renderer *renderer;
	SDL_CreateWindowAndRenderer(640, 480, SDL_WINDOW_RESIZABLE, &window, &renderer);
    surface = SDL_LoadBMP("Spaceship.bmp");
    texture = SDL_CreateTextureFromSurface(renderer, surface); 
	surface->clip_rect.h = 64;
	surface->clip_rect.w = 64;
	surface->clip_rect.x = x;
	surface->clip_rect.y = y;

	SDL_Texture* texture2;
	SDL_Surface* shoot;
	shoot = SDL_LoadBMP("laser.bmp");
	texture2 = SDL_CreateTextureFromSurface(renderer, shoot);
	shoot->clip_rect.h = 20;
	shoot->clip_rect.w = 10;
	shoot->clip_rect.x = x;
	shoot->clip_rect.y = y;

	while (quit == false)
	{
		if (i % 10 == 0 && shot == true)
		{
			shoot->clip_rect.y--;
		}
		if (SDL_PollEvent(&event))
		{
			
			switch (event.type)
			{
			case SDL_KEYDOWN:
			{
				
				switch (event.key.keysym.sym)
				{

				case SDLK_ESCAPE:
				{
					quit = true;
					break;
				}
				case SDLK_LEFT:
				{
					surface->clip_rect.x -= 10;
					break;
				}
				case SDLK_RIGHT:
				{
					surface->clip_rect.x += 10;
					break;
				}
				case SDLK_UP:
				{
					surface->clip_rect.y -= 10;
					break;
				}
				case SDLK_DOWN:
				{
					surface->clip_rect.y += 10;
					break;
				}
				case SDLK_SPACE:
				{
					if (j > 2)
					{
						j = 1;
					}
					++j;
					shoot->clip_rect.x = surface->clip_rect.x + 22;
					shoot->clip_rect.y = surface->clip_rect.y + 27;
					shot = true;
					break;
				}
				default:
					break;
				}
				
			}
			}
		
		}

		SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);

		SDL_RenderClear(renderer);

		SDL_RenderCopy(renderer, texture2, NULL, &shoot->clip_rect);

		SDL_RenderCopy(renderer, texture, NULL, &surface->clip_rect);

		SDL_RenderPresent(renderer);
		i++;
	}

	SDL_Quit();
	return(EXIT_SUCCESS);
}