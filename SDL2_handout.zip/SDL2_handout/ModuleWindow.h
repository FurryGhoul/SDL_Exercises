#ifndef __ModuleWindow_H__
#define __ModuleWindow_H__

#include "Module.h"
#include "Globals.h"
#include "SDL/include/SDL.h"

class ModuleWindow : public Module
{
public:
	bool Init();

	bool CleanUp()
	{
		LOG("Window CleanUp!");
		return true;
	}
private:
	SDL_Window* window = nullptr;
};
// TODO 1: Create the declaration of ModuleWindow class

#endif // __ModuleWindow_H__